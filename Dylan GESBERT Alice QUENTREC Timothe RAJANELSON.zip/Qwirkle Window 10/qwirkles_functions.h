#ifndef QWIRKLE_FUNCTIONS_H_INCLUDED
#define QWIRKLE_FUNCTIONS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <conio.h>

typedef struct JOUEUR{
    char name[20];
    short int tuiles[6];
    int score;
}JOUEUR;

void zoomConsole();

void piocheMelange(short int pioche[108],short int mode);

void affichageTuile(short int tuile);

void placementEcriture(int x,int y);

void menuPrincipalAffichage();

int keyDetection();

int sliderMenuDeplacement(int sliderMenu,int touche);

void affichageRegles();

void flecheMenuAffichage(int sliderMenu);

short int menuPrincipal();

int choixDuMode();

int nombreJoueurs();

void joueurInit(JOUEUR liste[],short int nbJoueur);

void affichageContourPlateau();

void flecheMenuJeu(short int choix);

void tuilesEnMain(JOUEUR joueurQuiJoue);

int affectationPioche(JOUEUR joueurQuiJoue[4],int tour,short int pioche[108],short int nbPiocheRestante,int iteration,short int nbJoueur,short int mode);

void piocheAffichage(short int pioche[108],short int mode);

short int choixMenuJeu(int key,short int choix);

void effacementFlecheJeu();

int minValue(int a,int b);

int maxValue(int a,int b);

int peutPoserTuile(JOUEUR listeJoueur[4],short int plateau[12][26],short int plateauPourScore[12][26],short int nbJoueur,int tour,int y,int x,short int tuile);

int placementTuile(JOUEUR listeJoueur[4],short int plateau[12][26],short int plateauPourScore[12][26],int tour,short int nbJoueur,short int choix,short int tuileInitiale);

void affichageScore(JOUEUR listeJoueur[4],short int nbJoueur,int x,int y);

void melangertuiles(short int nbPiocheRestante, short int pioche[108],short int mode);

void partie(JOUEUR listeJoueur[4],short int nbJoueur,short int mode,short int loading);

void sauvegarder(short int mode, short int nbJoueur,JOUEUR listeJoueur[4], short int pioche[108], short int nbPiocheRestante, short int tuileInitiale, short int plateau[12][26],int tour);



#endif
