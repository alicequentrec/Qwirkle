#include "qwirkles_functions.h"


void zoomConsole() {
    HWND console = GetConsoleWindow(); //la fonction renvoie un identificateur de fen�tre associ� � la fen�tre de la console de l'application. on met cet identificateur dans la varibale
    RECT r; //Cette ligne d�clare une structure r de type RECT qui sera utilis�e pour stocker les coordonn�es de la fen�tre de la console.
    GetWindowRect(console, &r); //remplit la structure r avec les coordonn�es de la fen�tre associ�e � console. Le premier argument est l'identificateur de la fen�tre et le second argument est un pointeur vers la structure r.
    MoveWindow(console, r.left, r.top, 530, 300, TRUE);//permet de redimensionner la fenetre associ� a console. ensuite on entre le point en haut a gauche de la fenetre donc r.left et r.top et ensuite on rajoute la longueur et la hauteur. le true indique qu'il faut redessiner ce qu'il y a dans la console mais c'est pas hyper utile dans ce cas car il y a normalement rien au moment o� elle est appel�e
}


void piocheMelange(short int pioche[108],short int mode){
    short int i;
    short int random;
    short int possible[37];


    for(i=0;i<36;i++){
        possible[i]=0;
    }

    i=0;
    switch(mode){//permet de savoir si on est en mode normal ou d�grad�e
    case 0:
        while(i<108){
            random = (rand()%36)+1;
            if(possible[random-1]<3){
                pioche[i] = random;
                possible[random-1]++;
                i++;
            }
        }
        break;

    case 1:
        while(i<36){
            random = rand()%36+1;
            if(possible[random-1]<1){
                pioche[i] = random;
                possible[random-1]++;
                i++;
            }
        }
        break;
    }
}


void affichageTuile(short int tuile){
    HANDLE handle; //utilisation de windows.h donc obligatoirement sur windows (on utilise pas conio.h car je (Dylan) pr�f�re utiliser windows.h � cause de l'habitude(meme si conio.h est surement plus facile pour faire la couleur mais elle fonctionne jamais pour moi)
    short int couleur;
    int temp;


    couleur = (tuile%6)+1;  //on initialise la couleur � afficher en fonction de la valeur de tuile en modulo 6
    if(couleur==1){couleur=14;} //on convertit le bleu fonc� en jaune claire pour avoir les bonnes couleurs pour le jeu

    //commandes que j'ai r�alis� lors d'un de mes projet d'affiche de bitmap dans la console
    handle=GetStdHandle(STD_OUTPUT_HANDLE); //std_output_handle c'est le buffer de l'ecran (donc l� de la console)
    SetConsoleTextAttribute(handle,couleur);//on modifie le texte en utilisant un nombre (pour la couleur) et le handle est techniquement le std_output_handle
    temp =tuile/6;

    if(tuile==1){temp=0;}
    ///En cas d'utilisation de Window11 il faut desactiver ce switch case car l'affichage du high ascii et low ascii bug un peu. Il faudra si vous utilisez window 11 utiliser le printf qui se trouve apres ce switch case. Il fonctionne cependant parfaitement sur window 10 /**
    switch(temp){

        case 0:
            printf("%c",3);
            break;
        case 1:
            printf("%c",4);
            break;
        case 2:
            printf("%c",5);
            break;
        case 3:
            printf("%c",2);
            break;
        case 4:
            printf("%c",254);
            break;
        case 5:
            printf("%c",14);
            break;
        default:
            printf("%c",3);
            break;

    }
    /// */

    ///si Vous utiliser windows 11 alors activez la ligne suivante
    ///printf("%c",tuile/6+65);
    SetConsoleTextAttribute(handle,7);//reset de couleur en blanc avec fond noir
}


void placementEcriture(int x,int y){
    COORD coord = { x, y };//on fait une variable coord avec un x et un y dedans(la struct est normalement d�finit par windows.h)
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);//permet de placer le curseur a la position x y. le GetStdHandle permet de r�cuperer un identificateur(un handle) associ� � la console(dans ce cas l� STD_OUTPUT_HANDLE qui signifie un identificateur associ� � la sortie standard de la console
}


void menuPrincipalAffichage(){
    placementEcriture(0,0);
    printf("----------QWIRKLE----------\n");
    printf("     Jouer \n     R%cgles\n     Charger\n     Quitter\n",138);
}


int keyDetection(){
    if(_kbhit()){ //si une touche du clavier est entree
        int key;
        key = _getch(); //on recup�re la touche entree mais sous forme d'entier

        switch(key){
        case 122:
            return 2;       //z=122
            break;
        case 113:
            return 3;       //q=113
            break;
        case 115:
            return 4;       //s=115
            break;
        case 100:
            return 5;       //d=100
            break;
        case 101:
            return 6;       //e=101
            break;
        case 116:
            return 7;
            break;
        case 13:
        case 32:
            return 1;       //espace=32     enter=13
            break;

        }
    }
    return 0;
}


int sliderMenuDeplacement(int sliderMenu,int touche){

    switch(touche){
    case 2:
        if(sliderMenu>0){ return -1;}
        break;
    case 4:
        if(sliderMenu<3){ return 1;}
        break;
    }
    return 0;
}


void affichageRegles(){
    system("cls");                  //clear la console
    placementEcriture(0,0);
    printf("----------Les Regles !----------\n\n");

    printf("But du jeu: Le but du jeu est de placer des tuiles en correspondance avec d autres tuiles de la meme forme ou de la meme couleur.\n");
    printf("Nombre de joueurs: Le jeu peut etre joue par 2 a 4 joueurs.\n\n");
    printf("Materiel: Chaque jeu comprend 108 tuiles de 6 formes differentes et  6 couleurs differentes.\n\n");
    printf("Deroulement du jeu: Le jeu commence avec le premier joueur qui place une tuile sur la table. Les autres joueurs doivent ensuite ajouter   une ou plusieurs tuiles en correspondance avec celles deja sur la    table.\n\n");
    printf("Correspondance: Une correspondance se produit lorsqu une tuile est   placee en ligne avec d autres tuiles de la meme forme ou de la meme  couleur.\n\n");
    printf("Points: Chaque fois qu un joueur cree une correspondance, il marque  des points. Le nombre de points depend du nombre de tuiles impliquees dans la correspondance.\n\n");
    printf("Fin du jeu: Le jeu se termine lorsqu un joueur n a plus de tuiles ou lorsqu il n y a plus de tuiles disponibles. Le joueur avec le plus   grand nombre de points gagne.\n\n");
    printf("Mode Degradee: Il existe le mode degradee dans lequel il y a que 36  tuiles au total pour la partie.\n\n");


    printf("Appuyer sur une touche pour continuer.");
    getch();                        //on attend un input du clavier. permet juste d'attendre que l'user appuie sur une touche
    system("cls");                  //clear la console
    placementEcriture(0,0);
    menuPrincipalAffichage();       //affichage du menu principale

}


void flecheMenuAffichage(int sliderMenu){
    placementEcriture(2,1);
    printf(" ");
    placementEcriture(2,2);
    printf(" ");
    placementEcriture(2,3);
    printf(" ");
    placementEcriture(2,4);
    printf(" ");
    placementEcriture(2,sliderMenu+1);
    printf("%c",16);
    placementEcriture(0,0);
}


short int menuPrincipal(){
    int menu;
    int sliderMenu;
    int touche;


    sliderMenu =0;
    menu =1;

    menuPrincipalAffichage();
    flecheMenuAffichage(sliderMenu);
    while(menu){ //boucle du menu
        touche = keyDetection();     //les touches : Z Q S D pour les mouvement.     Espace/Entree pour confirmer


        /** on affiche la fleche � l'endroit souhait� en fonction de la valeur
            de sliderMenu. sliderMenu est incr�ment� par une fonction          */
        sliderMenu += sliderMenuDeplacement(sliderMenu,touche);
        if(touche!=0){
            flecheMenuAffichage(sliderMenu);
        }

        if(touche==1){
            switch(sliderMenu){
                case 0:            //bouton jouer
                    return 0;
                    break;
                case 1:            //bouton regles
                        affichageRegles();
                        flecheMenuAffichage(sliderMenu);
                    break;
                case 2:
                    return 1;       //on load
                    break;
                case 3:            //bouton quitter
                    system("cls"); //On clear la console
                    exit(0);       //On termine le programme
                    break;

            }
        }
    }
    return 0;
}


int choixDuMode(){
    int touche;
    int mode;

    mode =0;
    system("cls");

    /**affichage */
    placementEcriture(0,0);
    printf("----------Choix du mode----------");
    placementEcriture(7,4);
    printf("Normal");
    placementEcriture(17,4);
    printf("Degrad%ce",130);
    placementEcriture(9,3);
    printf("%c",31);


    while(1){
        placementEcriture(0,0);
        touche = keyDetection();

        switch(touche){
            case 3:
                mode =0;

                placementEcriture(9,3);
                printf("%c",31); //affichage de la fleche
                placementEcriture(19,3);
                printf(" "); //d�saffichage de la fleche se trouvant a la mauvaise position
                break;
            case 5:
                mode =1;
                placementEcriture(19,3);
                printf("%c",31);//affichage de la fleche
                placementEcriture(9,3);
                printf(" ");//d�saffichage de la fleche se trouvant a la mauvaise position
                break;
            case 1:
                return mode;
        }
    }
    return 0;
}


int nombreJoueurs(){
    int touche;
    int sliderMenu;

    sliderMenu=0;

    /**     affichage  */
    system("cls");
    placementEcriture(0,0);
    printf("----------Nombre de Joueur----------\n    2 Joueurs\n    3 Joueurs\n    4 Joueurs");
    flecheMenuAffichage(sliderMenu); //affichage de fl�ches

    while(1){
        touche = keyDetection();
        sliderMenu += sliderMenuDeplacement(sliderMenu,touche);
        if(sliderMenu>2){sliderMenu--;}

        if(touche!=0){
            flecheMenuAffichage(sliderMenu);
        }

        if(touche==1){
            switch(sliderMenu){
                case 0:
                    return 2;
                    break;
                case 1:
                    return 3;
                    break;
                default:
                    return 4;
                    break;

            }
        }
    }
}


void joueurInit(JOUEUR liste[],short int nbJoueur){
    int i;
    int j;
    for(i=0;i<nbJoueur;i++){
            system("cls");
            placementEcriture(0,0);
            printf("-------Entrez le nom des Joueurs-------");
            if(i>0){
                placementEcriture(1,4);
                printf("Joueur 1: %s",liste[0].name);
                if(i>1){
                    placementEcriture(1,5);
                    printf("Joueur 2: %s",liste[1].name);
                    if(i>2){
                        placementEcriture(1,6);
                        printf("Joueur 3: %s",liste[2].name);
                    }
                }
            }

            placementEcriture(1,2);
            printf("Entrez le nom du joueur %d [",i+1);
            placementEcriture(46,2);
            printf("]");
            do{
                placementEcriture(28,2);
                fgets(liste[i].name,19,stdin);
                fflush(stdin);
            }while(liste[i].name[1]=='\0');

            liste[i].name[19] = '\0';

            /**Init des variable du joueur a 0 sauf le nom qui vient d'etre entree */
            liste[i].score=0;
            for(j=0;j<6;j++){
                liste[i].tuiles[j]=0;
            }
    }
}


void affichageContourPlateau(){
    int i;
    int j;
    placementEcriture(0,0);
    printf("   ------Partie de QWIRKLE-----\n\n");
    printf("   %c",201);
    for(i=0;i<26;i++){printf("%c",205);}
    printf("%c\n",187);
    for(j=0;j<12;j++){
        printf("   %c",186);
        for(i=0;i<26;i++){printf(" ");}
        printf("%c\n",186);
    }
    printf("   %c",200);
    for(i=0;i<26;i++){printf("%c",205);}
    printf("%c",188);
    placementEcriture(38,1);
    printf("TOUR DE :");
    placementEcriture(35,3);
    printf("Vos tuiles :");
    placementEcriture(35,6);
    printf("FIN DE TOUR");
    placementEcriture(39,15);
    printf("Appuyer sur t pour sauvegarder");
}


void flecheMenuJeu(short int choix){
    placementEcriture(48,5);
    printf("            ");
    placementEcriture(33,6);
    printf(" ");

    switch(choix){
        case 0:
            placementEcriture(48,5);
            printf("%c",30);
            break;

        case 1:
            placementEcriture(50,5);
            printf("%c",30);
            break;

        case 2:
            placementEcriture(52,5);
            printf("%c",30);
            break;

        case 3:
            placementEcriture(54,5);
            printf("%c",30);
            break;

        case 4:
            placementEcriture(56,5);
            printf("%c",30);
            break;

        case 5:
            placementEcriture(58,5);
            printf("%c",30);
            break;

        case 6:
            placementEcriture(33,6);
            printf("%c",16);
            break;
    }
}


void tuilesEnMain(JOUEUR joueurQuiJoue){
    int i;
    placementEcriture(48,4);//positionnement du curseur pour �crire sur la premiere tuile de la main
    printf("            "); //clear de l'affichage des tuiles
    placementEcriture(48,4);//positionnement du curseur pour �crire sur la premiere tuile de la main
    for(i=0;i<6;i++){//on r�execute pour les 6 tuiles de la main du joueur qui joue
        if(joueurQuiJoue.tuiles[i]!=0){//si c'est une tuile
            affichageTuile(joueurQuiJoue.tuiles[i]);//affichage de la tuile
            printf(" ");
        }
        else printf("  ");
    }
}


int affectationPioche(JOUEUR joueurQuiJoue[4],int tour,short int pioche[108],short int nbPiocheRestante,int iteration,short int nbJoueur,short int mode){
    switch(mode){
        case 0:
    if(joueurQuiJoue[tour%nbJoueur].tuiles[iteration]==0 && nbPiocheRestante<109){
        joueurQuiJoue[tour%nbJoueur].tuiles[iteration]=pioche[nbPiocheRestante]; //nbPiocheRestante -1
        nbPiocheRestante++; //ajoute a nbpiocherestante 1
    }
    break;
        case 1:
    if(joueurQuiJoue[tour%nbJoueur].tuiles[iteration]==0 && nbPiocheRestante<37){
        joueurQuiJoue[tour%nbJoueur].tuiles[iteration]=pioche[nbPiocheRestante]; //nbPiocheRestante -1
        nbPiocheRestante++; //ajoute a nbpiocherestante 1
    }
    break;

    }
    return nbPiocheRestante;
}


void piocheAffichage(short int pioche[108],short int mode){ // pas utilis�
    int i;
    placementEcriture(0,18);
    switch(mode){
        case 0:
    for(i=0;i<108;i++){
        affichageTuile(pioche[i]);
    }
    break;
        case 1:
            for(i=0;i<36;i++){
        affichageTuile(pioche[i]);
    }
    }
}


short int choixMenuJeu(int key,short int choix){
    if(key==3){ //q
        if(choix>0){choix--;}
    }
    if(key==5){//d
        if(choix<5){choix++;}
    }
    if(key==2){// z
        choix=0;
    }
    if(key==4){//s
        choix=6;
    }

    return choix;
}


void effacementFlecheJeu(){
    placementEcriture(1,1);
    int i;
    for(i=2;i<15;i++){
            placementEcriture(1,i);
            printf(" ");
    }
    placementEcriture(1,1);
    printf("                              ");
}


int minValue(int a,int b){
    if (a < b) {
        return a;
    }
    return b;
}


int maxValue(int a,int b){
    if (a > b) {
        return a;
    }
    return b;
}


int peutPoserTuile(JOUEUR listeJoueur[4],short int plateau[12][26],short int plateauPourScore[12][26],short int nbJoueur,int tour,int y,int x,short int tuile){

    if(plateau[y][x]!=0){return 0;}
    if(plateau[maxValue(y-1,0)][x]==0 && plateau[minValue(y+1,11)][x]==0 && plateau[y][maxValue(x-1,0)]==0 && plateau[y][minValue(x+1,25)]==0 ){return 0;} //on verifie si y'a une case qui est pas vide autour sinon return 0

    int i;
    int j;
    short int temp[26][12];
    int score;
    int longueur;
    int hauteur;
    int rx;
    int lx;
    int ty;
    int by;

    for(i=0;i<12;i++){
        for(j=0;j<26;j++){
            temp[j][i] = plateau[i][j];
        }
    }
    temp[x][y] =tuile; //plateau des tuiles avec notre tuile ajout�

    int modeLongueur =0; //si modeLongueur =1 alors c'est couleur similaire et si c'est 2 alors c'est signe similaire


    rx=x;
    lx=x;
    ty=y;       //topY
    by=y;       //bottomY


    longueur=0;
    hauteur =0;

    /**On remplace les plateau[12][26] par temp[12][26]. temp sera modifi� en temps r�el par les tuiles qu'on poses
        Alors que plateau sera modifi� qu'� la fin du tour. On pourra calculer le score avec plateau et calculer
        Et calculer la possibilit� qu'on puisse poser une tuile */



    while(lx-1>=0 && plateau[y][lx-1]!=0){lx--;} //on cherche la tuile la plus a gauche qui appartient a la potentielle ligne de la tuile

    while(rx+1<26 && plateau[y][rx+1]!=0){rx++;} //on cherche la tuile la plus a droite qui appartient a la potentielle ligne de la tuile

    while(ty-1>=0 && plateau[ty-1][x]!=0){ty--;}//on cherche la tuile la plus en haut qui appartient a la potentielle colonne de la tuile

    while(by+1<12 && plateau[by+1][x]!=0){by++;}//on cherche la tuile la plus en bas qui appartient a la potentielle colonne de la tuile

    longueur= rx-lx+1;
    hauteur = by-ty+1;

    /** -----------------------------ON CHECK LA LIGNE -----------------------------*/
    if(longueur>1){ //si il y a une autre tuile sur la ligne
        int a = temp[lx][y]; // tuile la plus a gauche(peut etre notre tuile qu'on veut poser)
        int b = temp[lx+1][y]; //tuile la deuxieme plus a gauche (peut etre notre tuile qu'on veut poser)
        if(a==b){return 0;}//si la tuile est pareil alors impossible

        if(  (a%6!=b%6)  &&  ( (a/6)%6 != (b/6)%6 )  ){return 0;} //si la tuile est entierement differente alors impossible

        if(a%6==b%6){modeLongueur=1;}       //detection si la couleur est pareil
        else{modeLongueur=2;}               //sinon le signe est pareil


        for(i=lx;i<=rx;i++){
            for(j=lx;j<=rx;j++){
                if(i!=j)
                {
                    a=temp[i][y];
                    b=temp[j][y];
                    if(modeLongueur==1){
                        if(a%6!=b%6 || a==b ){return 0;}
                    }
                    if(modeLongueur==2){
                        if((a/6)%6!=(b/6)%6 || a==b ){return 0;}
                    }
                }
            }
        }
    }


    modeLongueur=0; //blindage au cas o� (normalement ne sert a rien)

    /** -----------------------------ON CHECK LA COLONNE -----------------------------*/
    if(hauteur>1){ //si il y a une autre tuile sur la ligne
        int a = temp[x][ty]; // tuile la plus en haut(peut etre notre tuile qu'on veut poser)
        int b = temp[x][ty+1]; //tuile la deuxieme plus en haut (peut etre notre tuile qu'on veut poser)
        if(a==b){return 0;}//si la tuile est pareil alors impossible

        if(  (a%6!=b%6)  &&  ( (a/6)%6 != (b/6)%6 )  ){return 0;} //si la tuile est entierement differente alors impossible

        if(a%6==b%6){modeLongueur=1;}       //detection si la couleur est pareil
        else{modeLongueur=2;}               //sinon le signe est pareil


        for(i=ty;i<=by;i++){
            for(j=ty;j<=by;j++){
                if(i!=j)
                {
                    a=temp[x][i];
                    b=temp[x][j];
                    if(modeLongueur==1){
                        if(a%6!=b%6 || a==b ){return 0;}
                    }
                    if(modeLongueur==2){
                        if( (a/6)%6 !=(b/6)%6 || a==b ){return 0;}
                    }
                }
            }
        }
    }

    /**calcul du score */
    //reset des valeurs de detection
    rx=x;
    lx=x;
    ty=y;       //topY
    by=y;       //bottomY

    score=0;
    longueur=0;//reset de longueur et hauteur
    hauteur =0;

    while(lx-1>=0 && plateauPourScore[y][lx-1]!=0){lx--;} //on cherche la tuile la plus a gauche qui appartient a la potentielle ligne de la tuile

    while(rx+1<26 && plateauPourScore[y][rx+1]!=0){rx++;} //on cherche la tuile la plus a droite qui appartient a la potentielle ligne de la tuile

    while(ty-1>=0 && plateauPourScore[ty-1][x]!=0){ty--;}//on cherche la tuile la plus en haut qui appartient a la potentielle colonne de la tuile

    while(by+1<12 && plateauPourScore[by+1][x]!=0){by++;}//on cherche la tuile la plus en bas qui appartient a la potentielle colonne de la tuile

    //on refait les calcul de longueur et hauteur SANS la tuile qu'on pose
    longueur= rx-lx;//on compte par directement la tuile qu'on a pos� car sinon pour l'ajout du score la tuile sera compt� deux fois
    hauteur = by-ty;//(c'est pour cela qu'il n'y a pas de +1)

    if((longueur>0 || hauteur>0) &&tour>0){
        score+=longueur+hauteur;//on ajoute le score fait par la ligne et la colonne form�e sans compte le point fait par la tuile pos�
    }
    if(longueur>4){score+=6;} //si la longueur ou la hauteur(sans la tuile qu'on a pos�) est sup�rieur � 5 :bonus 6points
    if(hauteur>4){score+=6;}
    score++;//on ajoute le score de la tuile qu'on pose
    //on compte par directement la tuile qu'on a pos�

    listeJoueur[tour%nbJoueur].score +=score; //incr�mentation de la variable score du joueur avec le score calcul� dans ce sous programme

    return 1;
}


int placementTuile(JOUEUR listeJoueur[4],short int plateau[12][26],short int plateauPourScore[12][26],int tour,short int nbJoueur,short int choix,short int tuileInitiale){
    int sliderX;
    int sliderY;
    int touche;
    int tuilePlacee;

    sliderX=13;
    sliderY=6;
    tuilePlacee=0;

    while(!tuilePlacee){
        touche = keyDetection();
        if(touche!=0){

            placementEcriture(1,sliderY+3);
            printf(" ");
            placementEcriture(sliderX+4,1);
            printf(" ");
            switch(touche){
                case 1:
                    if(tuileInitiale==0 || peutPoserTuile(listeJoueur,plateau,plateauPourScore,nbJoueur, tour, sliderY, sliderX, listeJoueur[tour%nbJoueur].tuiles[choix])==1){
                        plateau[sliderY][sliderX]= listeJoueur[tour%nbJoueur].tuiles[choix];
                        listeJoueur[tour%nbJoueur].tuiles[choix] =0;
                        tuilePlacee=1;
                        if(tuileInitiale==0){listeJoueur[tour%nbJoueur].score++;}
                    }
                    else{return 1;}
                    break;

                case 2:
                    if(sliderY>0){sliderY--;}
                    break;
                case 3:
                    if(sliderX>0){sliderX--;}
                    break;
                case 4:
                    if(sliderY<11){sliderY++;}
                    break;
                case 5:
                    if(sliderX<25){sliderX++;}
                    break;

            }
            placementEcriture(1,sliderY+3);
            printf("%c",16);
            placementEcriture(sliderX+4,1);
            printf("%c",31);
            placementEcriture(sliderX+4,sliderY+3);
        }
    }
    return 1;
}

void affichageScore(JOUEUR listeJoueur[4],short int nbJoueur,int x,int y){
    int i;
    placementEcriture(x,y-1);
    printf("Nom du joueur        score");

    for(i=0;i<nbJoueur;i++){
        if(listeJoueur[i].score>-1){
            placementEcriture(x,y+i);
            printf("%s",listeJoueur[i].name);
            placementEcriture(x+21,y+i);
            printf("%d",listeJoueur[i].score);
        }
    }
    placementEcriture(0,0);
}


void melangertuiles(short int nbPiocheRestante, short int pioche[108],short int mode){
    short int i;
    short int temp;
    short int random;
    switch(mode){
        case 0:


            for(i=nbPiocheRestante; i<108; i++){
                do{
                    random = rand()%108;
                }while(random<i);
                temp = pioche[i];
                pioche[i]= pioche[random];
                pioche[random] = temp;
            }
            break;
        case 1:
            for(i=nbPiocheRestante; i<36; i++){
                do{
                    random = rand()%36;
                }while(random<i);
                temp = pioche[i];
                pioche[i]= pioche[random];
                pioche[random] = temp;
            }
            break;
    }

}


void sauvegarder(short int mode, short int nbJoueur,JOUEUR listeJoueur[4], short int pioche[108], short int nbPiocheRestante, short int tuileInitiale, short int plateau[12][26],int tour) {
    FILE *sauvegarde = fopen("sauvegarde.txt", "w");
    if (sauvegarde == NULL) {
        exit(-1);
    }

    fprintf(sauvegarde, "%hi\n", mode);
    fprintf(sauvegarde, "%hi\n", nbJoueur);

    for (int i = 0; i < nbJoueur; i++) {
        fputs(listeJoueur[i].name, sauvegarde);
        fprintf(sauvegarde, "\n%i\n", listeJoueur[i].score);
        for (int j = 0; j < 6; j++) {
            fprintf(sauvegarde, "%hi\n", listeJoueur[i].tuiles[j]);
        }
    }

    for (int i = 0; i < 108 - 72 * mode; i++) {
        fprintf(sauvegarde, "%hi\n", pioche[i]);
    }

    fprintf(sauvegarde, "%hi\n", nbPiocheRestante);
    fprintf(sauvegarde, "%hi\n", tuileInitiale);
    for (int i = 0; i < 12; i++) {
        for (int j = 0; j < 26; j++) {
            fprintf(sauvegarde, "%hi\n", plateau[i][j]);
        }
    }
    fprintf(sauvegarde,"%d\n",tour+1); //on met tour plus 1 pour passer au joueur d'apr�s. sa �vite le cheat de reload la partie apres qu'on ai jou� pour de nouveau avoir des tuiles en main
  fclose(sauvegarde);
}

